<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/styleLogin.css">
</head>

<body>
	<div class="login">
	<form action="dologin.php" method="POST">
	
	<label>Username:</label>
	<input type="text" name="user" id="user">
	<br>
	<label>Password:</label>
	<input type="password" name="pass" id="pass">
	<br>
	<input type="submit"  id="btnLogin" value="submit">
</div>
</form>

</body>
</html>